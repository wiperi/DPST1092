#ifndef THREAD_CHAIN_H
#define THREAD_CHAIN_H

void my_main(void);
void thread_hello(void);

#endif // THREAD_CHAIN_H
