// A simple C program that attempts to be punny

#include <stdio.h>

int main(void)
{
  printf("Well, this was a MIPStake!\n");

  return 0;
}
