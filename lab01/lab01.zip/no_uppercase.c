#include <stdio.h>
#include <ctype.h>

int main(void) {
	return 0;
}
