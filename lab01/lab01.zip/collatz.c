#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	(void) argc, (void) argv; // keep the compiler quiet, should be removed
	return EXIT_SUCCESS;
}
