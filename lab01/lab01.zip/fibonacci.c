#include <stdio.h>
#include <stdlib.h>

#define SERIES_MAX 30

int main(void) {
    return EXIT_SUCCESS;
}
