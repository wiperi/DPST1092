extern int puts(const char *s);

int main(void)
{
    puts("Hello, World!");
    return 0;
}
